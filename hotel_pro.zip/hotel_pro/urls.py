from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns = [
    path('admin/', admin.site.urls),

    # CUSTOMER SITE
    path('', include('customer.urls')),

    # AUTH (login/signup/otp)
    path('', include('accounts.urls')),

    # SUPER ADMIN
    path('super/', include('superadmin.urls')),

    # HOTEL ADMIN
    path('hotel/', include('hotels.urls')),

]
    
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)